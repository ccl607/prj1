package com.group4.client;

import java.util.List;
import java.util.Map;

import com.group4.erp.EmpApprovalCheckDTO;
import com.group4.erp.EmployeeDTO;
import com.group4.erp.SalaryDTO;
import com.group4.erp.TimeDTO;
import com.group4.erp.HrListSearchDTO;


public interface LoginClientService {
	
	int getcusLoginCnt(CustomerLoginDTO cusLoginDTO);
	
}
