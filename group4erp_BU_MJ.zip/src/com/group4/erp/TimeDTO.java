package com.group4.erp;

public class TimeDTO {
	
	private String now_year;
	private String now_month;
	private String day;
	private String hour;
	private String minute;
	private String seconds;

	
	public String getNow_year() {
		return now_year;
	}
	public void setNow_year(String now_year) {
		this.now_year = now_year;
	}
	public String getNow_month() {
		return now_month;
	}
	public void setNow_month(String now_month) {
		this.now_month = now_month;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public String getHour() {
		return hour;
	}
	public void setHour(String hour) {
		this.hour = hour;
	}
	public String getMinute() {
		return minute;
	}
	public void setMinute(String minute) {
		this.minute = minute;
	}
	public String getSeconds() {
		return seconds;
	}
	public void setSeconds(String seconds) {
		this.seconds = seconds;
	}
	
}
