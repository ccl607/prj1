package com.group4.erp;

public class ReturnSalseContentDTO {
	private String book_name;
	private String id;
	private String return_comment;
	private String return_order_dt;
	
	
	public String getReturn_order_dt() {
		return return_order_dt;
	}
	public void setReturn_order_dt(String return_order_dt) {
		this.return_order_dt = return_order_dt;
	}
	public String getBook_name() {
		return book_name;
	}
	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getReturn_comment() {
		return return_comment;
	}
	public void setReturn_comment(String return_comment) {
		this.return_comment = return_comment;
	}
	
	
	
	
}
