package com.group4.erp;

public class SalaryDTO {
	

	private int emp_no;
	private String emp_name;
	private String jikup;
	private String salary_dt;
	private String salary;
	private String month_sal;
	private String avg_salary;
	private String mess_allowance;
	private String bus_trip_cnt;
	private String bus_trip_bonus;
	private String sum_payable;
	private String pension;
	private String health;
	private String emp_insurance;
	private String deduct;
	private String year;
	private String month;
	private String real_sal;
	

	public String getReal_sal() {
		return real_sal;
	}

	public void setReal_sal(String real_sal) {
		this.real_sal = real_sal;
	}

	public String getDeduct() {
		return deduct;
	}

	public void setDeduct(String deduct) {
		this.deduct = deduct;
	}
	
	public int getEmp_no() {
		return emp_no;
	}
	
	public void setEmp_no(int emp_no) {
		this.emp_no = emp_no;
	}
	
	public String getEmp_name() {
		return emp_name;
	}
	
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	
	public String getJikup() {
		return jikup;
	}
	
	public void setJikup(String jikup) {
		this.jikup = jikup;
	}
	
	public String getSalary_dt() {
		return salary_dt;
	}
	
	public void setSalary_dt(String salary_dt) {
		this.salary_dt = salary_dt;
	}
	
	public String getSalary() {
		return salary;
	}
	
	public void setSalary(String salary) {
		this.salary = salary;
	}
	
	public String getMonth_sal() {
		return month_sal;
	}
	
	public void setMonth_sal(String month_sal) {
		this.month_sal = month_sal;
	}
	
	public String getAvg_salary() {
		return avg_salary;
	}
	
	public void setAvg_salary(String avg_salary) {
		this.avg_salary = avg_salary;
	}
	
	public String getMess_allowance() {
		return mess_allowance;
	}
	
	public void setMess_allowance(String mess_allowance) {
		this.mess_allowance = mess_allowance;
	}
	
	public String getBus_trip_cnt() {
		return bus_trip_cnt;
	}
	
	public void setBus_trip_cnt(String bus_trip_cnt) {
		this.bus_trip_cnt = bus_trip_cnt;
	}
	
	public String getBus_trip_bonus() {
		return bus_trip_bonus;
	}
	
	public void setBus_trip_bonus(String bus_trip_bonus) {
		this.bus_trip_bonus = bus_trip_bonus;
	}
	
	public String getSum_payable() {
		return sum_payable;
	}
	
	public void setSum_payable(String sum_payable) {
		this.sum_payable = sum_payable;
	}
	
	public String getPension() {
		return pension;
	}
	
	public void setPension(String pension) {
		this.pension = pension;
	}
	
	public String getHealth() {
		return health;
	}
	
	public void setHealth(String health) {
		this.health = health;
	}
	
	public String getEmp_insurance() {
		return emp_insurance;
	}
	
	public void setEmp_insurance(String emp_insurance) {
		this.emp_insurance = emp_insurance;
	}
	
	public String getYear() {
		return year;
	}
	
	public void setYear(String year) {
		this.year = year;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	
	
	
}
