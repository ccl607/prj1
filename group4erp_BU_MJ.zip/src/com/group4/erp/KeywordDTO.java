package com.group4.erp;

public class KeywordDTO {
	
	private String srch_key;
	private String cus_id;
	private String srch_dt;
	
	public String getSrch_key() {
		return srch_key;
	}
	
	public void setSrch_key(String srch_key) {
		this.srch_key = srch_key;
	}
	
	public String getCus_id() {
		return cus_id;
	}
	
	public void setCus_id(String cus_id) {
		this.cus_id = cus_id;
	}
	
	public String getSrch_dt() {
		return srch_dt;
	}
	
	public void setSrch_dt(String srch_dt) {
		this.srch_dt = srch_dt;
	}

}
