package com.group4.erp;

public class HrDayoffDTO {
	private String emp_no;
	private String dayoff_cd;
	private String dayoff_name;
	private String start_dayoff;
	private String end_dayoff;
	private String using_dayoff;
	private String remain_dayoff;
	private String confirm;
	private String dayoff_apply_dt;
	
	
	public String getEmp_no() {
		return emp_no;
	}
	public void setEmp_no(String emp_no) {
		this.emp_no = emp_no;
	}
	public String getDayoff_cd() {
		return dayoff_cd;
	}
	public void setDayoff_cd(String dayoff_cd) {
		this.dayoff_cd = dayoff_cd;
	}
	
	public String getDayoff_name() {
		return dayoff_name;
	}
	public void setDayoff_name(String dayoff_name) {
		this.dayoff_name = dayoff_name;
	}
	public String getStart_dayoff() {
		return start_dayoff;
	}
	public void setStart_dayoff(String start_dayoff) {
		this.start_dayoff = start_dayoff;
	}
	public String getEnd_dayoff() {
		return end_dayoff;
	}
	public void setEnd_dayoff(String end_dayoff) {
		this.end_dayoff = end_dayoff;
	}
	public String getUsing_dayoff() {
		return using_dayoff;
	}
	public void setUsing_dayoff(String using_dayoff) {
		this.using_dayoff = using_dayoff;
	}
	public String getRemain_dayoff() {
		return remain_dayoff;
	}
	public void setRemain_dayoff(String remain_dayoff) {
		this.remain_dayoff = remain_dayoff;
	}
	public String getConfirm() {
		return confirm;
	}
	public void setConfirm(String confirm) {
		this.confirm = confirm;
	}
	public String getDayoff_apply_dt() {
		return dayoff_apply_dt;
	}
	public void setDayoff_apply_dt(String dayoff_apply_dt) {
		this.dayoff_apply_dt = dayoff_apply_dt;
	}
	
	
	
	
}
