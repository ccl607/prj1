package com.group4.erp;

public class WareHousingInsertDTO {
	
	private String isbn;
	private String datepicker;
	private int isbn_cnt;
	private int supply_rate;
	
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getDatepicker() {
		return datepicker;
	}
	public void setDatepicker(String datepicker) {
		this.datepicker = datepicker;
	}
	public int getIsbn_cnt() {
		return isbn_cnt;
	}
	public void setIsbn_cnt(int isbn_cnt) {
		this.isbn_cnt = isbn_cnt;
	}
	public int getSupply_rate() {
		return supply_rate;
	}
	public void setSupply_rate(int supply_rate) {
		this.supply_rate = supply_rate;
	}
	
	
}
