package com.group4.erp;

public class EmployeeDTO {
	

	//수정중
	private String emp_name;
	private String emp_eng_name;
	private String jumin_num;
	private String emp_gender;
	private String phone;
	private String emp_email;
	private String emp_email_office;
	private String mgr_emp_name;
	private String mgr_emp_no;
	private String emp_addr;
	private String emp_pwd;
	private String jikup;
	private String mgr;
	private String ceo_no;
	private String ceo_name;
	private int jikup_cd;
	private int worktime_cd;
	private int dep_no;
	private String emp_pic;
	
	
	public int getDep_no() {
		return dep_no;
	}

	public void setDep_no(int dep_no) {
		this.dep_no = dep_no;
	}

	public String getEmp_name() {
		return emp_name;
	}
	
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	
	public String getEmp_eng_name() {
		return emp_eng_name;
	}
	
	public void setEmp_eng_name(String emp_eng_name) {
		this.emp_eng_name = emp_eng_name;
	}
	
	public String getJumin_num() {
		return jumin_num;
	}
	
	public void setJumin_num(String jumin_num) {
		this.jumin_num = jumin_num;
	}
	
	public String getEmp_gender() {
		return emp_gender;
	}
	
	public void setEmp_gender(String emp_gender) {
		this.emp_gender = emp_gender;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public String getEmp_email() {
		return emp_email;
	}
	
	public void setEmp_email(String emp_email) {
		this.emp_email = emp_email;
	}
	
	public String getEmp_email_office() {
		return emp_email_office;
	}
	
	public void setEmp_email_office(String emp_email_office) {
		this.emp_email_office = emp_email_office;
	}
	
	public String getMgr_emp_name() {
		return mgr_emp_name;
	}
	
	public void setMgr_emp_name(String mgr_emp_name) {
		this.mgr_emp_name = mgr_emp_name;
	}
	
	public String getMgr_emp_no() {
		return mgr_emp_no;
	}
	
	public void setMgr_emp_no(String mgr_emp_no) {
		this.mgr_emp_no = mgr_emp_no;
	}
	
	public String getEmp_addr() {
		return emp_addr;
	}
	
	public void setEmp_addr(String emp_addr) {
		this.emp_addr = emp_addr;
	}
	
	public String getEmp_pwd() {
		return emp_pwd;
	}
	
	public void setEmp_pwd(String emp_pwd) {
		this.emp_pwd = emp_pwd;
	}
	
	public String getJikup() {
		return jikup;
	}
	
	public void setJikup(String jikup) {
		this.jikup = jikup;
	}
	
	public String getMgr() {
		return mgr;
	}
	
	public void setMgr(String mgr) {
		this.mgr = mgr;
	}
	
	public String getCeo_no() {
		return ceo_no;
	}
	
	public void setCeo_no(String ceo_no) {
		this.ceo_no = ceo_no;
	}
	
	public String getCeo_name() {
		return ceo_name;
	}
	
	public void setCeo_name(String ceo_name) {
		this.ceo_name = ceo_name;
	}
	
	public int getJikup_cd() {
		return jikup_cd;
	}
	
	public void setJikup_cd(int jikup_cd) {
		this.jikup_cd = jikup_cd;
	}
	
	public int getWorktime_cd() {
		return worktime_cd;
	}
	
	public void setWorktime_cd(int worktime_cd) {
		this.worktime_cd = worktime_cd;
	}
	
	public String getEmp_pic() {
		return emp_pic;
	}
	
	public void setEmp_pic(String emp_pic) {
		this.emp_pic = emp_pic;
	}

}
